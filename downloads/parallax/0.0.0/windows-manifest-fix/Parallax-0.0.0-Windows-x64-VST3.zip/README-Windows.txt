Parallax by Sustx Audio - Windows x64 VST3

Requires Windows 10 version 1607 or later / Windows 11 and an x64 VST3 DAW.
This is a Windows binary, not the macOS version. It was cross-compiled on
macOS and has not yet been tested in a Windows DAW.

1. Close your DAW and extract this ZIP.
2. Copy the entire Parallax.vst3 folder into:
   C:\Program Files\Common Files\VST3\
   Windows may ask for administrator authorization.
3. Restart your DAW and rescan VST3 plug-ins.
4. Look for Sustx Audio - Parallax.
5. Open Parallax, click Copy request code, and send that code with your name to
   Sustx Audio. Import the .parallax-license file you receive to unlock the effect.

Without a valid license, the effect is disabled and audio passes through dry.
Once unlocked, Parallax works offline with no expiry.

Keep the folder structure intact. Do not copy only the file inside Contents.
Remove older manually installed Parallax copies elsewhere to avoid duplicates.
Back up your previous Parallax.vst3 folder before replacing it.

To uninstall, close your DAW, remove that Parallax.vst3 folder, and rescan.
